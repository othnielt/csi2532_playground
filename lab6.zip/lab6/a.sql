
DELETE from artworks
where  artist_name = 'Smith';

DELETE from artists
where name = 'Smith';